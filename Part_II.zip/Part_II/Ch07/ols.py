import datetime as dt
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm

data = pd.read_csv('vs_es.csv', index_col=0, parse_dates=True, dayfirst=True)
rets = np.log(data / data.shift(1))

xdat = rets['EUROSTOXX']
ydat = rets['VSTOXX']

xdat.dropna(inplace=True)
ydat.dropna(inplace=True)

data.plot(subplots=True, grid=True, style='b', figsize=(15,9))
plt.show()
rets.plot(subplots=True, grid=True, style='b', figsize=(15,9))
plt.show()

'''
xdat = rets['EUROSTOXX']
ydat = rets['VSTOXX']
model = pd.ols(y=ydat, x=xdat)
print(model)
print(model.beta)
'''

x = np.array(xdat)
X = sm.add_constant(x)
y = np.array(ydat)

model = sm.OLS(y, X)
results = model.fit()
print(results.summary())

b0 = results.params[0]
b1 = results.params[1]

plt.figure(figsize=(15,9))
plt.plot(xdat, ydat, 'r.')
ax = plt.axis()
x = np.linspace(ax[0], ax[1]+0.01)
plt.plot(x, b0 + b1 * x, 'b', lw=2)
plt.grid(True)
plt.axis('tight')
plt.xlabel('EURO STOXX 50 returns')
plt.ylabel('VSTOXX returns')
plt.show()

#pd.rolling_corr(rets['EUROSTOXX'], rets['VSTOXX'], window=252).plot(grid=True, style='b')
TSrolling = rets['EUROSTOXX'].rolling(window=252).corr(other=rets['VSTOXX'])
plt.figure(figsize=(15,9))
TSrolling.plot(grid=True, style='b')
plt.show()

