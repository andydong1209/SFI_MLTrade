import numpy as np
import pandas as pd
import pandas_datareader.data as web
from sklearn.decomposition import KernelPCA

symbols = ['ADS.DE', '^GDAXI']

data = pd.DataFrame()
for sym in symbols:
    data[sym] = web.DataReader(sym, data_source='yahoo', start='2010-01-01', end='2015-12-31')['Close']
data = data.dropna()

dax = pd.DataFrame(data.pop('^GDAXI'))
data.head()

'''
h5 = pd.HDFStore('DAXCompAll.h5', complevel=9, complib='blosc')
for sym in symbols:
    h5[sym] = data[sym]    
h5.close()
'''
