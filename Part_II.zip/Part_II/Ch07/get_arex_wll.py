import datetime
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import pandas_datareader.data as web

start_date = datetime.datetime(2012, 1, 1)
end_date = datetime.datetime(2013, 1, 1)
arex = web.DataReader("AREXQ", "yahoo", start=start_date, end=end_date)
wll = web.DataReader("WLL", "yahoo", start='1/1/2012', end='1/1/2013')

arex.to_csv("AREXQ.csv")
wll.to_csv("WLL.csv")
