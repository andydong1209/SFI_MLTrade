# cadf_gldgdx.py
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import statsmodels.tsa.stattools as ts

gld = pd.read_csv('GLD.csv')
gdx = pd.read_csv('GDX.csv')
df = pd.DataFrame(index=gld.index)
df['GLD'] = gld['Adj Close']
df['GDX'] = gdx['Adj Close']
y = df['GLD']
x = df['GDX']

# Plot the two time series
plt.figure(figsize=(14, 10))
plt.subplot(211)
plt.plot(y, lw=1.5, label='gld')
plt.plot(y, 'ro')
plt.grid(True)
plt.legend(loc=0)
plt.ylabel('$Price$')
plt.title('Time Serice of Prices')

plt.subplot(212)
plt.plot(x, 'g', lw=1.5, label='gdx')
plt.plot(x, 'bx')
plt.grid(True)
plt.legend(loc=0)
plt.ylabel('$Price$')
plt.xlabel('$Date$')
plt.show()

# Display a scatter plot of the two time series
plt.figure(figsize=(14, 10))
plt.xlabel('%s Price ($)' % 'GDX')
plt.ylabel('%s Price ($)' % 'GLD')
plt.title('%s and %s Price Scatterplot' % ('GDX', 'GLD'))
plt.scatter(df['GLD'], df['GDX'])
plt.show()

X = sm.add_constant(x)
model = sm.OLS(y, X)
results = model.fit()
beta_hr = results.params[1]
print(beta_hr)

# Calculate the residuals of the linear combination
df['res'] = df['GLD'] - beta_hr*df['GDX']
spread = df['res']

# Plot the residuals
plt.figure(figsize=(14, 7))
plt.plot(spread, lw=1.5, label='spread')
plt.grid(True)
plt.legend(loc=0)
plt.xlabel('$Date$')
plt.ylabel('$Spread Price$')
plt.title('Pair Trade Performance')
plt.show()

# Calculate and output the CADF test on the residuals
cadf = ts.adfuller(df['res'])
print(cadf)


# 1.300366111844379
# (-2.596279102384878, 0.09376874253309969, 6, 244, 
# {'1%': -3.457437824930831, '5%': -2.873459364726563, '10%': -2.573122099570008}, 
#     378.8273095360996)

