#!/usr/bin/python
# -*- coding: utf-8 -*-

# forecast.py

from __future__ import print_function

import datetime
import numpy as np
import pandas as pd
import pandas_datareader.data as web

from sklearn.linear_model import LogisticRegression


def create_lagged_series(symbol, start_date, end_date, lags=5):
	"""
	This creates a Pandas DataFrame that stores the
	percentage returns of the adjusted closing value of
	a stock obtained from Yahoo Finance, along with a
	number of lagged returns from the prior trading days
	(lags defaults to 5 days). Trading volume, as well as
	the Direction from the previous day, are also included.
	"""


if __name__ == "__main__":
	# Create a lagged series of the S&P500 US stock market index
	snpret = create_lagged_series(
		"^GSPC", datetime.datetime(2001, 1, 10),
		datetime.datetime(2005, 12, 31), lags=5)
	
	# Use the prior two days of returns as predictor
	# values, with direction as the response
	X = snpret[["Lag1", "Lag2"]]
	y = snpret["Direction"]
	
	# The test data is split into two parts: Before and after 1st Jan 2005.
	start_test = datetime.datetime(2005, 1, 1)

	"""
	# Create training and test sets
	X_train = X[X.index < start_test]
	X_test = X[X.index >= start_test]
	y_train = y[y.index < start_test]
	y_test = y[y.index >= start_test]

	# test print(y_test)

	# Create the (parametrised) models
	print("Hit Rates/Confusion Matrices:\n")
	model = [("LR", LogisticRegression())]

	# Iterate through the models
	# Train each of the models on the training set
	model[1].fit(X_train, y_train)
	# Make an array of predictions on the test set
	pred = m[1].predict(X_test)

	# Output the hit-rate and the confusion matrix for each model
	print("%s:\n%0.3f" % (m[0], m[1].score(X_test, y_test)))
	"""
