import datetime
from datetime import timedelta

import numpy as np
import pandas as pd
import pandas_datareader.data as web

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix

# Obtain stock information from IEX
start_date = datetime.datetime(2016, 1, 1)
start = '2016-01-01'
end_date = datetime.datetime(2018, 12, 31)
end = '2018-12-31'
beg_date = start_date-timedelta(days=365) # (2015, 1, 10)
beg = '2015-01-02'

'''
src = "iex"
lags = 5
ts = web.DataReader("SPY", src, beg_date, end_date)
'''

# or obtain stock information from CSV(from IEX Data)
ts = pd.read_csv('IEX_SPY.csv', index_col = 0) # 1006

# Create the new lagged DataFrame
tslag = pd.DataFrame(index = ts.index)
tslag["Today"] = ts["close"]
tslag["Volume"] = ts["volume"]

lags = 5
# Create the shifted lag series of prior trading period close values
for i in range(0, lags):
	tslag["Lag%s" % str(i+1)] = ts["close"].shift(i+1)
	
# Create the returns DataFrame
tsret = pd.DataFrame(index=tslag.index)
tsret["Volume"] = tslag["Volume"]
tsret["Today"] = tslag["Today"].pct_change()*100.0

# If any of the values of percentage returns equal zero, set them to
# a small number (stops issues with QDA model in Scikit-Learn)
for i, x in enumerate(tsret["Today"]):
	if abs(x) < 0.0001:
		tsret.iloc[i, 1] = 0.0001

# Create the lagged percentage returns columns
for i in range(0, lags):
	tsret["Lag%s" % str(i+1)] = tslag["Lag%s" % str(i+1)].pct_change()*100.0

print(tsret.tail())
print(tsret[0:10])
tsret = tsret[tsret.index >= '2015-01-12'] # 1000
# tsret = tsret[lag+1:]

# Create the "Direction" column (+1 or -1) indicating an up/down day
tsret["Direction"] = np.sign(tsret["Today"]) # 1000
tsret = tsret[tsret.index >= start] # 754

# Use the prior two days of returns as predictor values, with direction as the response
X = tsret[["Lag1", "Lag2"]] # 754
y = tsret["Direction"] # 754



