from __future__ import print_function

import datetime
import numpy as np
import pandas as pd
import pandas_datareader.data as web

from datetime import timedelta

from sklearn.linear_model import LogisticRegression

# Obtain stock information from Yahoo Finance
start_date = datetime.datetime(2005, 1, 1)
end_date = datetime.datetime(2005, 12, 31)

lags = 5
start_train = datetime.datetime(2005, 1, 1) + timedelta(days=lags+2)
start_test = datetime.datetime(2005, 9, 1)

ts = web.DataReader("^GSPC", "yahoo", start_date, end_date)
print(ts)
	
# Create the new lagged DataFrame
tslag = pd.DataFrame(index = ts.index)
tslag["Today"] = ts["Adj Close"]
tslag["Volume"] = ts["Volume"]

# Create the shifted lag series of prior trading period close values
for i in range(0, lags):
	tslag["Lag%s" % str(i+1)] = ts["Adj Close"].shift(i+1)
	
# Create the returns DataFrame
tsret = pd.DataFrame(index=tslag.index)
tsret["Volume"] = tslag["Volume"]
tsret["Today"] = tslag["Today"].pct_change()*100.0

# If any of the values of percentage returns equal zero, set them to
# a small number (stops issues with QDA model in Scikit-Learn)
for i, x in enumerate(tsret["Today"]):
	if abs(x) < 0.0001:
		tsret["Today"][i] = 0.0001

# Create the lagged percentage returns columns
for i in range(0, lags):
	tsret["Lag%s" % str(i+1)] = tslag["Lag%s" % str(i+1)].pct_change()*100.0

# Create the "Direction" column (+1 or -1) indicating an up/down day
tsret["Direction"] = np.sign(tsret["Today"])
print(tsret)

tsret = tsret[tsret.index >= start_train]
print(tsret)


