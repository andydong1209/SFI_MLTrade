import datetime

import numpy as np
import pandas as pd

import pandas_datareader.data as web

start = datetime.datetime(2015, 1, 2)
end = datetime.datetime(2019, 2, 28)
ts = web.DataReader("SPY", "iex", start, end)

ts.to_csv('IEX_SPY.csv')

h5 = pd.HDFStore('IEX_SPY.h5', complevel=9, complib='blosc')
h5['sp_stock'] = ts
h5.close()

