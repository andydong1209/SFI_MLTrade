import datetime as dt
import numpy as np
import pandas as pd
from pandas_datareader.data import DataReader

start_date = dt.datetime(2001,1,10) - dt.timedelta(days=365)
end_date = dt.datetime(2005,12,31)


gspc = DataReader("^GSPC", "yahoo", start_date, end_date)
gspc.to_csv("SP500.csv")

'''
gspc = pd.read_csv("SP500.csv", index_col=0, parse_dates=True, 
	infer_datetime_format=True)
'''
