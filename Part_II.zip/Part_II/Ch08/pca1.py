import numpy as np
import pandas as pd
import pandas_datareader.data as web
from sklearn.decomposition import KernelPCA

symbols = ['ADS.DE', 'ALV.DE', 'BAS.DE', 'BAYN.DE', 'BEI.DE',
           'BMW.DE', 'CBK.DE', 'CON.DE', 'DAI.DE', 'DB1.DE',
           'DBK.DE', 'DPW.DE', 'DTE.DE', 'EOAN.DE', 'FME.DE',
           'FRE.DE', 'HEI.DE', 'HEN3.DE', 'IFX.DE', 'LHA.DE',
           'LIN.DE', 'LXS.DE', 'MRK.DE', 'MUV2.DE', 'RWE.DE',
           'SAP.DE', 'SDF.DE', 'SIE.DE', 'TKA.DE', 'VOW3.DE',
           '^GDAXI']


# data = pd.DataFrame()
# for sym in symbols:
#    data[sym] = web.DataReader(sym, data_source='yahoo', start='2010-01-01', end='2015-12-31')['Close']
# data = data.dropna()
# data.to_hdf('DAXCompAll.h5', key='data', mode='w')

data = pd.DataFrame()
data = pd.read_hdf('DAXCompAll.h5', 'data');

print(data)

data[data.columns[:6]].head()    
dax = pd.DataFrame(data.pop('^GDAXI'))
print(dax)
print(data)
