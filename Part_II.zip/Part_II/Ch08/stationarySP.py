import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import seaborn as sb


gspc = pd.read_csv('SP500Long.csv', index_col=0, parse_dates=True,
    infer_datetime_format=True)

gspc['Natural Log'] = gspc['Adj Close'].apply(lambda x: np.log(x))
gspc['LogReturn'] = gspc['Natural Log'] - gspc['Natural Log'].shift()

'''
gspc['LogReturnL1'] = gspc['LogReturn'].shift()
gspc['LogReturnL2'] = gspc['LogReturn'].shift(2)
gspc['LogReturnL5'] = gspc['LogReturn'].shift(5)
gspc['LogReturnL30'] = gspc['LogReturn'].shift(30)

sb.set_style('darkgrid')
sb.jointplot('LogReturn', 'LogReturnL1', gspc, kind='reg', size=12)
plt.show()
'''

from statsmodels.tsa.stattools import acf
from statsmodels.tsa.stattools import pacf

lag_correlations = acf(gspc['LogReturn'].iloc[1:])  
lag_partial_correlations = pacf(gspc['LogReturn'].iloc[1:])  

fig, ax = plt.subplots(figsize=(14, 10))
ax.plot(lag_correlations, marker='o', linestyle='--')
plt.title('S&P500 Log Return acf')
plt.grid(True)
plt.show()


from statsmodels.tsa.seasonal import seasonal_decompose

decomposition = seasonal_decompose(gspc['Natural Log'], model='additive', freq=30)
fig = decomposition.plot()
plt.show()
