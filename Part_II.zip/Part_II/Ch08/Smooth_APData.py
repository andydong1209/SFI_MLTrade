from datetime import datetime
import pandas as pd
import numpy as np
import matplotlib.pylab as plt
from matplotlib.pylab import rcParams


dateparse = lambda dates: pd.datetime.strptime(dates, '%Y-%m')
data = pd.read_csv('AirPassengers.csv', parse_dates=True, 
    index_col='Month', date_parser=dateparse)

ts = data['#Passengers']
rcParams['figure.figsize'] = 16, 9

ts_log = np.log(ts)
plt.plot(ts_log)
plt.xlabel('Date')
plt.ylabel('Number')
plt.title('Log Time Series')
plt.show()

'''
moving_avg = ts_log.rolling(window=12, center=False).mean()
plt.plot(ts_log)
plt.plot(moving_avg, color='red')
plt.xlabel('Date')
plt.ylabel('Number')
plt.title('Moving Average Time Series')
plt.show()

ts_log_moving_avg_diff = ts_log - moving_avg
print ts_log_moving_avg_diff.head(12)

ts_log_moving_avg_diff.dropna(inplace=True)
'''

from statsmodels.tsa.stattools import adfuller
def test_stationarity(timeseries):    
    #Determing rolling statistics
    rolmean = timeseries.rolling(window=12, center=False).mean()
    rolstd = timeseries.rolling(window=12, center=False).std()

    #Plot rolling statistics:
    orig = plt.plot(timeseries, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.xlabel('Date')	
    plt.title('Rolling Mean & Standard Deviation')
    plt.show(block=False)
    
    #Perform Dickey-Fuller test:
    print 'Results of Dickey-Fuller Test:'
    dftest = adfuller(timeseries, autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    for key,value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
    print dfoutput


#test_stationarity(ts_log_moving_avg_diff)
#plt.show()


expwighted_avg = ts_log.ewm(halflife=12,ignore_na=False,min_periods=0,adjust=True).mean()
plt.plot(ts_log)
plt.plot(expwighted_avg, color='red')
plt.xlabel('Date')
plt.title('Exponential Weighted Moving Average Time Series')
plt.show()

ts_log_ewma_diff = ts_log - expwighted_avg
test_stationarity(ts_log_ewma_diff)
plt.show()

