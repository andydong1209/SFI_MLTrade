import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


'''
import os
import datetime as dt
import pandas_datareader.data as web
import statsmodels.api as sm
import seaborn as sb
sb.set_style('darkgrid')
'''

gspc = pd.read_csv('SP500Long.csv', index_col=0, parse_dates=True,
    infer_datetime_format=True)


'''
gspc['Adj Close'].plot(figsize=(16, 8))
plt.xlabel('Date')
plt.ylabel('Price')
plt.title('S&P500 Time Series')
plt.grid(True)
plt.show()


gspc['First Difference'] = gspc['Adj Close'] - gspc['Adj Close'].shift()
gspc['First Difference'].plot(figsize=(16, 8))
plt.xlabel('Date')
plt.ylabel('First Difference')
plt.title('S&P500 Time Series First Difference')
plt.grid(True)
plt.show()
'''

gspc['Natural Log'] = gspc['Adj Close'].apply(lambda x: np.log(x))
# gspc['Natural Log'].plot(figsize=(16, 8))
# plt.xlabel('Date')
# plt.ylabel('Log Price')
# plt.title('S&P500 Time Series Log Price')
# plt.grid(True)
# plt.show()


#gspc['Original Variance'] = pd.rolling_var(gspc['Adj Close'], 30, min_periods=None, freq=None, center=True)
#gspc['Log Variance'] = pd.rolling_var(gspc['Natural Log'], 30, min_periods=None, freq=None, center=True)
gspc['Original Variance'] = gspc['Adj Close'].rolling(window=30, center=True).var()
gspc['Log Variance'] = gspc['Natural Log'].rolling(window=30, center=True).var()


# fig, ax = plt.subplots(2, 1, figsize=(12, 10))
# gspc['Original Variance'].plot(ax=ax[0], title='Original Variance')
# gspc['Log Variance'].plot(ax=ax[1], title='30days Log Variance')
# fig.tight_layout()
# plt.xlabel('Date')
# plt.grid(True)
# plt.show()


gspc['LogReturn'] = gspc['Natural Log'] - gspc['Natural Log'].shift()
# gspc['LogReturn'].plot(figsize=(16, 8), title='Log Return')
# plt.xlabel('Date')
# plt.ylabel('Log Return')
# plt.grid(True)
# plt.show()


gspc['LogReturn Variance'] = gspc['LogReturn'].rolling(window=30, center=True).var()
gspc['LogReturn Volatility'] = gspc['LogReturn'].rolling(window=30, center=True).std()
gspc['LogReturn Volatility'].plot(figsize=(16, 8), title='30days Volatility')
plt.xlabel('Date')
plt.ylabel('Volatility')
plt.grid(True)
plt.show()
