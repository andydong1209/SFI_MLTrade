Set.seed(1)
x <- seq(1, 100) + 20.0*rnorm(1:100)
Set.seed(2)
y <- seq(1, 100) + 20.0*rnorm(1:100)
plot(x, y)

cov(x, y)

cor(x, y)

w <- rnoem(100)
acf(w)

w <- seq(1, 100)
acf(w)

w <- rep(1:10, 10)
acf(w)


