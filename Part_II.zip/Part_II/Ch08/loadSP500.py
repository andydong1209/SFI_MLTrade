import numpy as np  
import pandas as pd  
import pandas_datareader.data as web

# gspc = web.DataReader('^GSPC', 'yahoo', start='1/1/1964', end='5/30/2016')
gspc = pd.read_csv('SP500Long.csv')

print(gspc.info())
print(gspc[0:10])
# gspc.to_csv('SP500Long.csv')

