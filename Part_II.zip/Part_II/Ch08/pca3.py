import numpy as np
import pandas as pd
from sklearn.decomposition import KernelPCA
import matplotlib as mpl
import matplotlib.pyplot as plt

symbols = ['ADS.DE', 'ALV.DE', 'BAS.DE', 'BAYN.DE', 'BEI.DE',
           'BMW.DE', 'CBK.DE', 'CON.DE', 'DAI.DE', 'DB1.DE',
           'DBK.DE', 'DPW.DE', 'DTE.DE', 'EOAN.DE', 'FME.DE',
           'FRE.DE', 'HEI.DE', 'HEN3.DE', 'IFX.DE', 'LHA.DE',
           'LIN.DE', 'LXS.DE', 'MRK.DE', 'MUV2.DE', 'RWE.DE',
           'SAP.DE', 'SDF.DE', 'SIE.DE', 'TKA.DE', 'VOW3.DE',
           '^GDAXI']

data = pd.DataFrame()
data = pd.read_hdf('DAXCompAll.h5')

dax = pd.DataFrame(data.pop('^GDAXI'))

scale_function = lambda x: (x - x.mean()) / x.std()
pca = KernelPCA().fit(data.apply(scale_function))
print(len(pca.lambdas_))
print(pca.lambdas_[:10].round())

get_we = lambda x: x / x.sum()
print(get_we(pca.lambdas_)[:10])
print(get_we(pca.lambdas_)[:6].sum())

pca = KernelPCA(n_components=1).fit(data.apply(scale_function))
#dax['PCA_1'] = pca.transform(-data)
dax['PCA_1'] = pca.transform(data)

dax.apply(scale_function).plot(figsize=(12, 6))
plt.show()

pca = KernelPCA(n_components=6).fit(data.apply(scale_function))
#pca_components = pca.transform(-data)
pca_components = pca.transform(data)
weights = get_we(pca.lambdas_)
dax['PCA_6'] = np.dot(pca_components, weights)
dax.apply(scale_function).plot(figsize=(12, 6))
plt.show()

mpl_dates = mpl.dates.date2num(data.index.date)

plt.figure(figsize=(12, 6))
plt.scatter(dax['PCA_6'], dax['^GDAXI'], c=mpl_dates)
lin_reg = np.polyval(np.polyfit(dax['PCA_6'],dax['^GDAXI'], 1), dax['PCA_6'])
plt.plot(dax['PCA_6'], lin_reg, 'r', lw=3)
plt.grid(True)
plt.xlabel('PCA_6')
plt.ylabel('^GDAXI')
plt.colorbar(ticks=mpl.dates.DayLocator(interval=250), 
    format=mpl.dates.DateFormatter('%d %b %y'))
plt.show()

cut_date = '2011/7/1'
early_pca = dax[dax.index < cut_date]['PCA_6']
early_reg = np.polyval(np.polyfit(early_pca, dax['^GDAXI'][dax.index < cut_date], 1), early_pca)
late_pca = dax[dax.index >= cut_date]['PCA_6']
late_reg = np.polyval(np.polyfit(late_pca,dax['^GDAXI'][dax.index >= cut_date], 1),late_pca)

plt.figure(figsize=(12, 6))
plt.scatter(dax['PCA_6'], dax['^GDAXI'], c=mpl_dates)
plt.plot(early_pca, early_reg, 'r', lw=3)
plt.plot(late_pca, late_reg, 'r', lw=3)
plt.grid(True)
plt.xlabel('PCA_6')
plt.ylabel('^GDAXI')
plt.colorbar(ticks=mpl.dates.DayLocator(interval=250),format=mpl.dates.DateFormatter('%d %b %y'))
plt.show()
