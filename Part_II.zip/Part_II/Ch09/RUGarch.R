require(rugarch)
data(dmbp)
dmbp
spec = ugarchspec()
fit = ugarchfit(data = dmbp[,1], spec = spec)
forc = ugarchforecast(fit, n.ahead=20)
forc
ind = forc@forecast$seriesFor
ind
