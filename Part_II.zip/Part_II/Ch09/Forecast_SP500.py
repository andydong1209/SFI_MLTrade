import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm

gspc = pd.read_csv('SP500Long.csv', index_col=0, parse_dates=True, infer_datetime_format=True)
gspc['Natural Log'] = gspc['Adj Close'].apply(lambda x: np.log(x))
gspc['LogReturn'] = gspc['Natural Log'] - gspc['Natural Log'].shift()

model = sm.tsa.ARIMA(gspc['Natural Log'].iloc[1:], order=(1, 0, 0))
results = model.fit(disp=-1)
gspc['Forecast'] = results.fittedvalues
gspc[['Natural Log', 'Forecast']].plot(figsize=(16, 9))
plt.show()

model = sm.tsa.ARIMA(gspc['LogReturn'].iloc[1:], order=(1, 0, 0))
results = model.fit(disp=-1)
gspc['Forecast'] = results.fittedvalues
gspc[['LogReturn', 'Forecast']].plot(figsize=(16, 9))
plt.show()

gspc[['LogReturn', 'Forecast']].iloc[1200:1600, :].plot(figsize=(16, 9))
plt.show()

model = sm.tsa.ARIMA(gspc['LogReturn'].iloc[1:], order=(0, 0, 1))
results = model.fit(disp=-1)  
gspc['Forecast'] = results.fittedvalues  
gspc[['LogReturn', 'Forecast']].plot(figsize=(16, 9)) 
plt.show()

