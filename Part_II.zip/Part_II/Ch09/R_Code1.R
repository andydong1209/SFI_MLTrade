set.seed(1)
x <- w <- rnorm(100)
for (t in 2:100) x[t] <- 0.6*x[t-1] + w[t]

layout(1:2)
plot(x, type='l')
acf(x)

x.ar <- ar(x, method = "mle")
x.ar$order
[1] 1

x.ar$ar
[1] 0.5231187

x.ar$ar + c(-1.96, 1.96) * sqrt(x.ar$asy.var)
[1] 0.3556050 0.6906324


set.seed(1)
x <- w <- rnorm(100)
for (t in 3:100) x[t] <- 0.666*x[t-1] - 0.333*x[t-2] + w[t]

layout(1:2)
plot(x, type='l')
acf(x)

x.ar <- ar(x, method = "mle")
x.ar$order
x.ar$ar


require('quantmod')
getSymbols('AMZN', src='yahoo')
AMZN
plot(Cl(AMZN))

amznrt = diff(log(Cl(AMZN)))
plot(amznrt)

acf(amznrt, na.action = na.omit)

amznrt.ar <- ar(amznrt, na.action=na.omit)
amznrt.ar$order
amznrt.ar$ar
amznrt.ar$asy.var


getSymbols('^GSPC', src='yahoo')
GSPC
plot(Cl(GSPC))

gspcrt = diff(log(Cl(GSPC)))
plot(gspcrt)

acf(gspcrt, na.action = na.omit)

gspcrt.ar <- ar(gspcrt, na.action=na.omit)
gspcrt.ar$order
gspcrt.ar$ar
gspcrt.ar$asy.var



