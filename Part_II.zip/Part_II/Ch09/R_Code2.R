set.seed(1)
x <- w <- rnorm(100)
for (t in 2:100) x[t] <- w[t] + 0.6 * w[t-1]
layout(1:2)
plot(x, type='l')
acf(x)

x.ma <- arima(x, order=c(0, 0, 1))
x.ma

0.6023 + c(-1.96, 1.96)*0.0827


set.seed(1)
x <- w <- rnorm(1000)
for (t in 4:1000) x[t] <- w[t] + 0.6 * w[t-1] + 0.4 * w[t-2] + 0.3 * w[t-3]
layout(1:2)
plot(x, type='l')
acf(x)

x.ma <- arima(x, order=c(0, 0, 3))
x.ma


require('quantmod')
getSymbols('AMZN', src='yahoo')
AMZN
amznrt = diff(log(Cl(AMZN)))
plot(amznrt)

amznrt.ma <- arima(amznrt, order=c(0, 0, 1))
amznrt.ma
acf(amznrt.ma$res[-1])

amznrt.ma <- arima(amznrt, order=c(0, 0, 2))
amznrt.ma
acf(amznrt.ma$res[-1])

amznrt.ma <- arima(amznrt, order=c(0, 0, 3))
amznrt.ma
acf(amznrt.ma$res[-1])


getSymbols('^GSPC', src='yahoo')
gspcrt = diff(log(Cl(GSPC)))
plot(gspcrt)

gspcrt.ma <- arima(gspcrt, order=c(0, 0, 1))
gspcrt.ma
acf(gspcrt.ma$res[-1])

gspcrt.ma <- arima(gspcrt, order=c(0, 0, 2))
gspcrt.ma
acf(gspcrt.ma$res[-1])

gspcrt.ma <- arima(gspcrt, order=c(0, 0, 3))
gspcrt.ma
acf(gspcrt.ma$res[-1])

gspc


acf(gspcrt, na.action = na.omit)

gspcrt.ar <- ar(gspcrt, na.action=na.omit)
gspcrt.ar$order
gspcrt.ar$ar
gspcrt.ar$asy.var
