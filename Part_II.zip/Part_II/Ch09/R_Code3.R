set.seed(1)
x <- arima.sim(n=1000, model=list(ar=0.5, ma=-0.5))
plot(x)

acf(x)

arima(x, order=c(1, 0, 1))


set.seed(1)
x <- arima.sim(n=1000, model=list(ar=c(0.5, -0.25), ma=c(0.5, -0.3)))
plot(x)

acf(x)

arima(x, order=c(2, 0, 2))


set.seed(3)
x <- arima.sim(n=1000, model=list(ar=c(0.5, -0.25, 0.4), ma=c(0.5, -0.3)))
final.aic <-Inf
final.order <- c(0, 0, 0)
for (i in 0:4) for (j in 0:4) {
  current.aic <- AIC(arima(x, order=c(i, 0, j)))
  if (current.aic < final.aic) {
    final.aic <- current.aic
    final.order <- c(i, 0, j)
    final.arma <- arima(x, order=final.order)
  }
}

final.aic

final.order

final.arma

Box.test(resid(final.arma), lag=20, type="Ljung-Box")




require('quantmod')
getSymbols('^GSPC', src='yahoo')
sp = diff(log(Cl(GSPC)))

spfinal.aic <-Inf
spfinal.order <- c(0, 0, 0)
for (i in 0:4) for (j in 0:4) {
  spcurrent.aic <- AIC(arima(sp, order=c(i, 0, j)))
  if (spcurrent.aic < spfinal.aic) {
    spfinal.aic <- spcurrent.aic
    spfinal.order <- c(i, 0, j)
    spfinal.arma <- arima(sp, order=spfinal.order)
  }
}

spfinal.aic

spfinal.order

spfinal.arma

acf(resid(spfinal.arma), na.action=na.omit)

Box.test(resid(spfinal.arma), lag=20, type="Ljung-Box")




require('quantmod')
getSymbols('AMZN', from="2013-01-01")
amzn = diff(log(Cl(AMZN)))

azfinal.aic <-Inf
azfinal.order <- c(0, 0, 0)
for (p in 0:4) for (d in 0:1) for (q in 0:4) {
  azcurrent.aic <- AIC(arima(amzn, order=c(p, d, q)))
  if (azcurrent.aic < azfinal.aic) {
    azfinal.aic <- azcurrent.aic
    azfinal.order <- c(p, d, q)
    azfinal.arima <- arima(amzn, order=azfinal.order)
  }
}

azfinal.aic

azfinal.order

azfinal.arima

acf(resid(azfinal.arima), na.action=na.omit)

Box.test(resid(azfinal.arima), lag=20, type="Ljung-Box")

azpredict <- predict(azfinal.arima, n.ahead = 12)


