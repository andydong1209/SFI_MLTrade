require('quantmod')
getSymbols('AMZN', src='yahoo')
AMZN
plot(Cl(AMZN))

amznrt = diff(log(Cl(AMZN)))
plot(amznrt)

acf(amznrt, na.action = na.omit)

amznrt.ar <- ar(amznrt, na.action=na.omit)
amznrt.ar$order
amznrt.ar$ar
amznrt.ar$asy.var

