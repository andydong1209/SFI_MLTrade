import numpy as np
from datetime import datetime

def datestr2num(ndary):
    lstdates = list(ndary)
    strdates = list()
    weekdates = list()
    num = len(lstdates)
    for i in range(num):
        strdates.append(str(lstdates[i]))
        weekdates.append(datetime.strptime(strdates[i], "%d-%m-%Y").date().weekday())               
    return weekdates

def pricestr2flt(ndary):
    lstprice = list(ndary)
    fltprice = list()
    strprice = list()
    num = len(lstprice)
    for i in range(num):
        strprice.append(str(lstprice[i]))
        fltprice.append(float(strprice[i]))
    return fltprice

# Monday 0, Tuesday 1, Wednesday 2, Thursday 3, Friday 4, Saturday 5, Sunday 6
# nddates, ndclose = np.loadtxt('data.csv', dtype='str', delimiter=',', usecols=(1, 6), unpack=True)
nddates = np.loadtxt('data.csv', dtype='str', delimiter=',', usecols=(1,), unpack=True)
ndclose = np.loadtxt('data.csv', dtype='float', delimiter=',', usecols=(6,), unpack=True)

#print(type(ndweekdates))
#print(ndclose)

'''
fltclose = list()
fltclose = pricestr2flt(ndclose)
weekdates = list()
weekdates = datestr2num(nddates)
'''

weekdates = list()
weekdates = datestr2num(nddates)
averages = np.zeros(5)
ndweekdates = np.array(weekdates)

for i in range(5):
    indices = np.where(ndweekdates == i)
    prices = np.take(ndclose, indices)
    avg = np.mean(prices)
    print("Day", i, "prices", prices, "Average", avg)
    averages[i] = avg

top = np.max(averages)
print("Highest average", top)
print("Top day of the week", np.argmax(averages))
bottom = np.min(averages)
print("Lowest average", bottom)
print("Bottom day of the week", np.argmin(averages))
