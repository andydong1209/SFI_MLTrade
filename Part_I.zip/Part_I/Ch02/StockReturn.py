import numpy as np

c=np.loadtxt('data.csv', delimiter=',', usecols=(6,), unpack=True) #len(c)=30, 0...29
returns = np.diff( c ) / c[ : -1] # c[:-1] : 0~28, diff(c) : 0~28
print("Standard deviation =", np.std(returns))

logreturns = np.diff( np.log(c) )
posretindices = np.where(returns > 0) # Tuple
print("Indices with positive returns", posretindices)

daily_volatility = np.std(logreturns)
annual_volatility = daily_volatility / np.sqrt(1./252.)
monthly_volatility = annual_volatility * np.sqrt(1./12.)

print("Daily volatility", daily_volatility)
print("Annual volatility", annual_volatility)
print("Monthly volatility", monthly_volatility)
