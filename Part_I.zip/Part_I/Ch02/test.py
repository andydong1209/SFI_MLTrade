# -*- coding: utf-8 -*-
from __future__ import print_function
from numpy import *

a = arange(9)
b = arange(12)
a.shape = (3, 3)
b.shape = (3, 4)

print(a)
print(b)
