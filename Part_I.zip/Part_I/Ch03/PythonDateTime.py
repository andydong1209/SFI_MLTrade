from datetime import datetime

date = datetime(year=2015, month=7, day=4)
date

from dateutil import parser
date1 = parser.parse("4th of July, 2015")
date1
date1.strftime('%A')
