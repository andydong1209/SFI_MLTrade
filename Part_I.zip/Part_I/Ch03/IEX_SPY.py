import datetime
from datetime import timedelta

import numpy as np
import pandas as pd
import pandas_datareader.data as web

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix

# Obtain stock information from IEX
start_date = datetime.datetime(2016, 1, 1)
start = '2016-01-01'
end_date = datetime.datetime(2018, 12, 31)
end = '2018-12-31'
beg_date = start_date-timedelta(days=365) # (2015, 1, 10)
beg = '2015-01-02'

src = "iex"
lags = 5
ts = web.DataReader("SPY", src, beg_date, end_date)

ts.to_csv('IEX_SPY.csv')

h5 = pd.HDFStore('IEX_SPY.h5', complevel=9, complib='blosc')
h5['sp_stock'] = ts
h5.close()


"""
import datetime
from datetime import date
from datetime import timedelta

import numpy as np
import pandas as pd
import pandas_datareader.data as web

now = date.today()
yr = now.year
mn = now.month
dd = now.day - 3

start_date = datetime.datetime(yr-4, mn, dd)
end_date = datetime.datetime(yr, mn, dd)
beg_date = start_date-timedelta(days=365)
src = "iex"
lags = 5
ts = web.DataReader("SPY", src, beg_date, end_date)
"""



"""
import datetime

import numpy as np
import pandas as pd

import pandas_datareader.data as web

start = datetime.datetime(2015, 1, 2)
end = datetime.datetime(2019, 2, 28)
ts = web.DataReader("SPY", "iex", start, end)

ts.to_csv('IEX_SPY.csv')

h5 = pd.HDFStore('IEX_SPY.h5', complevel=9, complib='blosc')
h5['sp_stock'] = ts
h5.close()
"""
