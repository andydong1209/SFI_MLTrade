# %matplotlib inline
import numpy as np
import matplotlib.pyplot as plt

plt.style.use('classic')

x = np.linspace(0, 10, 100)

plt.figure() # create a plot figure

# create the first of two panels and set current axis
plt.subplot(2, 1, 1) # (rows, columns, panel number)
plt.plot(x, np.sin(x))

# create the second panel and set current axis
plt.subplot(2, 1, 2)
plt.plot(x, np.cos(x));

plt.show()