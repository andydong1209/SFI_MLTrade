# -*- coding: utf-8 -*-
from __future__ import print_function
import numpy as np
import pandas as pd

dates = pd.date_range('20130101', periods=6, freq='D')
print(dates)

df = pd.DataFrame(np.random.randn(6, 4), index=dates, columns=list('ABCD'))
print(df)

df1 = pd.DataFrame(np.random.randn(6, 4), index=dates, columns=['1st','2nd','3rd','4th'])
print(df1)

df2 = pd.DataFrame({ 
	'A' : 1., 
	'B' : pd.Timestamp('20130102'), 
	'C' : pd.Series(1,index=list(range(4)),dtype='float32'),
	'D' : np.array([3] * 4,dtype='int32'),
	'E' : pd.Categorical(["test","train","test","train"]),
	'F' : 'foo' })
print(df2)

print(df['20130101'])

