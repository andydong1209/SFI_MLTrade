import numpy as np
import matplotlib.pyplot as plt

plt.style.use('classic')
x = np.linspace(0, 10, 100)
fig = plt.figure()
plt.plot(x, np.sin(x))
plt.plot(x, np.cos(x))
plt.show()

fig.savefig('my_figure.png')

from IPython.display import Image
Image('my_figure.png')
 
