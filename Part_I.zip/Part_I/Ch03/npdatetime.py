import numpy as np

date = np.array('2015-07-04', dtype=np.datetime64)
date
dates = date + np.arange(12)
dates

