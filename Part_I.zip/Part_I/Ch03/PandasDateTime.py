import pandas as pd

date = pd.to_datetime("4th of July, 2015")
date

date.strftime('%A')

idx = date + pd.to_timedelta(np.arange(12), 'D')


dates = pd.to_datetime([datetime(2015, 7, 3), '4th of July, 2015', '2015-Jul-6', '07-07-2015', '20150708'])
dates

dates.to_period('D')
dates

dates - dates[0]
