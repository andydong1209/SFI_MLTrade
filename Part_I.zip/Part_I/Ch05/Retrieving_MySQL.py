#!/usr/bin/python
# -*- coding: utf-8 -*-

import pandas as pd
import pymysql as mdb

if __name__ == "__main__":
    # Connect to the MySQL instance
    db_host = "localhost"
    db_user = "andydong"
    db_pass = "12096581"
    db_name = "securities_master"
    con = mdb.connect(db_host, db_user, db_pass, db_name)

    # Select all of the historic Google adjusted close data
    sql = """SELECT * FROM daily_price"""

# Create a pandas dataframe from the SQL query
ibm = pd.read_sql_query(sql, con=con, index_col="price_date")

# Output the dataframe tail
print(ibm)
print(ibm.iloc[0])
