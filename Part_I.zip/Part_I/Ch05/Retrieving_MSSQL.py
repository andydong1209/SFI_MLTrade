# -*- coding: utf-8 -*-
from __future__ import print_function
import pandas as pd
import pytds

# Connect to the MS SQL instance
db_host = "HD5F-ESC2000"
db_user = "sa"
db_pass = "1qaz!QAZ"
db_name = "PRICE"
conn = pytds.connect(db_host, db_name, db_user, db_pass)

# Select all of the historic Google adjusted close data
sql="SELECT * FROM Price1W WHERE QuoteDateTime < "2010-01-09 23:59:00.000" "


# Create a pandas dataframe from the SQL query
forex = pd.read_sql_query(sql, con=conn, index_col="QuoteDateTime")
conn.close()

# Output the dataframe tail
print(forex.tail())

