from __future__ import print_function
import pandas as pd
import pytds

# Connect to the MS SQL instance
db_host = "HD5F-ESC2000"
db_user = "sa"
db_pass = "1qaz!QAZ"
db_name = "PRICE"
conn = pytds.connect(db_host, db_name, db_user, db_pass)

# Select all of the historic Google adjusted close data
sql = '''
    SELECT * FROM Price1D 
    WHERE  QuoteDateTime > '2016-01-01 00:00:00.000' AND Code = 'EUR_USD';
    '''

# Create a pandas dataframe from the SQL query
forex = pd.read_sql_query(sql, con=conn, index_col='QuoteDateTime')

conn.close()

# Output the dataframe tail
print(forex.tail())

h5 = pd.HDFStore("2016_EURUSD.h5", complevel=9, complib="blosc")
h5["EURUSD"] = forex
h5.close()

