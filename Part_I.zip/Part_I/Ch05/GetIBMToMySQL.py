#!/usr/bin/python
# -*- coding: utf-8 -*-
# GetIBMToMySQL.py
import datetime
import warnings
import numpy as np
import pandas as pd
import pandas_datareader.data as web
import pymysql as mdb
import requests

# Obtain a database connection to the MySQL instance
db_host = "localhost"
db_user = "andydong"
db_pass = "12096581"
db_name = "securities_master"
con = mdb.connect(db_host, db_user, db_pass, db_name)

tag_code = "IBM"
ibm = web.DataReader(tag_code, data_source='yahoo', start='11/30/2018', end='12/10/2018')
price_length = ibm.shape[0]

now = datetime.datetime.utcnow()

daily_data = [("1", "IBM", ibm.index[i].to_pydatetime(), now, now, 
    np.format_float_positional(ibm.iloc[i][0], 2), np.format_float_positional(ibm.iloc[i][1], 2), 
    np.format_float_positional(ibm.iloc[i][2], 2), np.format_float_positional(ibm.iloc[i][3], 2), 
    np.format_float_positional(ibm.iloc[i][4], 2), np.format_float_positional(ibm.iloc[i][5], 2)) 
    for i in range(price_length)]

column_str = """data_vendor_id, symbol_id, price_date, created_date,
    last_updated_date, open_price, high_price, low_price,
    close_price, volume, adj_close_price"""
    
insert_str = ("%s, " * 11)[:-2]
final_str = "INSERT INTO daily_price (%s) VALUES (%s)" % (column_str, insert_str)
    
# Using the MySQL connection, carry out an INSERT INTO for every symbol
with con:
    cur = con.cursor()
    cur.executemany(final_str, daily_data)
