import pytds

with pytds.connect("localhost\\SQLEXPRESS", "AutoLot", "", "") as conn:
	cursor = conn.cursor()	
	cursor.execute("SELECT * FROM dbo.Customers")
	row = cursor.fetchone()
	while row:
		print("FirstName=%s, LastName=%s" % (row[1], row[2]))
		row = cursor.fetchone()
	conn.close()
