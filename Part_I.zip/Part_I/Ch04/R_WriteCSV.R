require(quantmod)

sAAPL <- getSymbols("AAPL", from="2015-01-01", to="2018-12-31")

dim(AAPL)

write.csv(AAPL, "R_AAPL.csv")

write.table(AAPL, "R_AAPL_1.csv", append = FALSE, sep = ",", dec = ".", row.names = TRUE, col.names = TRUE)

