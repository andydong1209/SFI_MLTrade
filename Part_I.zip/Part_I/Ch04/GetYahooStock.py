import pandas as pd
import pandas_datareader.data as web

ca_df = web.DataReader('2816.TW', data_source='yahoo', start='1/1/2015', end='5/30/2016')
print(ca.info())
print(ca[0:10])

cs_df = web.DataReader('6016.TWO', data_source='yahoo', start='1/1/2015', end='5/30/2016')
print(cs.info())
print(cs[0:10])

ca_df.to_csv('ChinaAirline.csv')
cs_df.to_csv('ConcordSec.csv')
