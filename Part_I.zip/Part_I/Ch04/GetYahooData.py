import pandas as pd
import pandas_datareader.data as web

sp = web.DataReader('^GSPC', data_source='yahoo', start='1/1/2015', end='5/30/2016')
print(sp.info())
print(sp[0:10])

ibm = web.DataReader('IBM', data_source='yahoo', start='1/1/2015', end='5/30/2016')
print(ibm.info())
print(ibm[0:10])

h5 = pd.HDFStore('2015_SP_IBM.h5', complevel=9, complib='blosc')
h5['ibm_stock'] = ibm
h5['sp_stock'] = sp
h5.close()

ca_df = web.DataReader('2816.TW', data_source='yahoo', start='1/1/2015', end='5/30/2016')
print(ca_df.info())
print(ca_df[0:10])

cs_df = web.DataReader('6016.TWO', data_source='yahoo', start='1/1/2015', end='5/30/2016')
print(cs_df.info())
print(cs_df[0:10])

ca_df.to_csv('ChinaAirline.csv')
cs_df.to_csv('ConcordSec.csv')

