import pandas as pd
ca_df = pd.read_csv('ChinaAirline.csv')

print(ca_df.info())
print(ca_df.head())
print(ca_df.tail())

