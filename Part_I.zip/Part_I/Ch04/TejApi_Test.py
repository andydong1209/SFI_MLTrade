﻿# -*- coding: utf-8 -*-
"""
Created on Mar 7 2019
@author: yorick

"""
#pip install tejapi
#pip install scipy
#pip install matplotlib

#%%
import pandas as pd  
import numpy as np

#%%
# link TEJ API
import tejapi 
# input key
tejapi.ApiConfig.api_key = "GDEy0mWAGqnI3EemCREGREZMcEVbnF"
# set period
sampledates = ['2015-01-01','2018-12-31']
# claim the indexs set of TW50'c components
code=['1101','1102','1216','1301','1303','1326','1402','2002','2105','2227',
    '2301','2303','2308','2317','2327','2330','2352','2354','2357','2382',
    '2395','2408','2409','2412','2454','2474','2492','2609','2610','2633',
    '2801','2823','2880','2881','2882','2883','2884','2885','2886','2887',
    '2890','2891','2892','2912','3008','3045','3481','3711','4904','4938',
    '5871','5880','6505','9904','0050']
# store the (date and close price)
data_raw= tejapi.get('TWN/APRCD', coid=code, mdate={'gte':sampledates[0],'lte':sampledates[1]},
    opts={"sort":"mdate.desc", 'columns':['coid','mdate','close_d']}, paginate=True)

# view data
data_raw.head()

#%%
# reset index of date
clean = data_raw.set_index('mdate')
# transpose
returns = clean.pivot(columns='coid')
# set stock name
returns.columns = [columns[1] for columns in returns.columns]
returns.head()