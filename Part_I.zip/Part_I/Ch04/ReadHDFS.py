import pandas as pd

sp_df = pd.read_hdf('2015_SP_IBM.h5', 'sp_stock')
ibm_df = pd.read_hdf('2015_SP_IBM.h5', 'ibm_stock')

sp_df.head()
ibm_df.head()

sp_df.to_hdf('sp_stock.h5', 'sp_stock', append=True)
ibm_df.to_hdf('ibm_stock.h5', 'ibm_stock', append=True)


