# -*- coding: utf-8 -*-
from __future__ import print_function

a = 3
b = 4
c = a + b
print(c)

"""
# concate string in one line
print("Hello,", "world!")
print("Andy", "Dong")

print("Hello,", "world!", sep="*", end=" ")
print("Andy", "Dong", sep="*")
"""

list = range(0, 10, 1)
A = list[-3:]
for i in A:
	print(i)

